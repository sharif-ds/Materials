#include "testlib.h"
using namespace std;

int main(int argc, char* argv[]) {
	registerChecker("valley", argc, argv);
	int cor = ans.readInt();
	int out = ouf.readInt();

	if (cor != out) {
		quitf(_wa, "Expected %d, found %d", cor, out);
	}
	compareRemainingLines();
}
