#include<bits/stdc++.h> 
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;

const ll maxn = 1024;
const ll mod = 1e9 + 7;
const ll inf = 1e18;

#define rep(i, a, b) for(int i = (a); i < (b); i++)
#define fast_io ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define file_io freopen("input.txt", "r", stdin);freopen("output.txt", "w", stdout);
#define pb push_back
#define Mp make_pair
#define F first
#define S second
#define SZ(x) int((x).size())
#define all(x) (x).begin(), (x).end()

int n, m;
string s[maxn];
string t[maxn];

int dx[4] = {-1, 0, 1, 0};
int dy[4] = {0, -1, 0, 1};

bool ok(int x, int y){
	return (0 <= x && x < n && 0 <= y && y < m);
}

bool vis[maxn][maxn];

void dfs(int x, int y){
	if(!ok(x, y)) return;
	if(vis[x][y]) return;
	vis[x][y] = 1;
	if(t[x][y] != '.' && t[x][y] != 'A' && t[x][y] != 'o') return;
	rep(i, 0, 4){
		int nx = x + dx[i];
		int ny = y + dy[i];
		dfs(nx, ny);
	}
}

int main(int argc, char const *argv[])
{
	ifstream test_in(argv[1]);    /* This stream reads from test's input file   */
	ifstream test_out(argv[2]);   /* This stream reads from test's output file  */
	ifstream user_out(argv[3]);   /* This stream reads from user's output file  */
 
	/* Your code here */
	/* If user's output is correct, return 0, otherwise return 1       */
	
	test_in >> n >> m;
	rep(i, 0, n){
		test_in >> s[i];
	}
	string mode;
	test_in >> mode;
	string to, uo;
	getline(test_out, to);
	getline(user_out, uo);
	if(to != uo) return 1;
	if(to[0] == 'C') return 0;
	
	string st;
	test_out >> st;
	if(st == "nope") return 0;
	
	rep(i, 0, n){
		user_out >> t[i];
	}
	int cnt = stoi(to);
	rep(i, 0, n){
		rep(j, 0, m){
			if(s[i][j] == 'A') dfs(i, j);
			if(s[i][j] != t[i][j]){
				if(s[i][j] == '*' && t[i][j] == 'o') cnt--;
				else return 1;
			}
		}
	}
	if(cnt) return 1;
	rep(i, 0, n){
		rep(j, 0, m){
			if((s[i][j] == 'B' || s[i][j] == 'C') && !vis[i][j]) return 1;
		}
	}
	
	return 0;
}
